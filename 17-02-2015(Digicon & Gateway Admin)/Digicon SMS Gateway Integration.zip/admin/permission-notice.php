<?php
require 'initapp.php';
$self='permission-notice.php';
require ("views/$theme/permission-notice.tpl.php");

?>