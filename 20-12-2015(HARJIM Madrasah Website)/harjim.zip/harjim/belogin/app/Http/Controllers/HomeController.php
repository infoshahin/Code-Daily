<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App;
use App\About;
use App\SliderImage;
use App\Event;
use App\Weblink;
use App\PrincipalSpeech;


class HomeController extends Controller
{

    public function index($lang)
    {
        App::setLocale($lang);
         $SliderImage = SliderImage::all();
         $Event = Event::all();
         $weblink = Weblink::all();
        $principalSpeech = PrincipalSpeech::find(3);
        return View('pages.frontend.home')->with('principalSpeech',$principalSpeech)->with('lang',$lang)->with('SliderImage',$SliderImage)->with('Event',$Event)->with('weblink',$weblink);
    }


    public function contact($lang)
    {
        App::setLocale($lang);
        return View('pages.frontend.contact')->with('lang',$lang);
    }

     public function admin($lang)
        {
            App::setLocale($lang);
            return View('layouts.backend.login')->with('lang',$lang);
        }
     public function history($lang)
        {
            App::setLocale($lang);
            $about = About::find(1);
            return View('pages.frontend.about')->with('lang',$lang)->with('about',$about);
        }


    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  Request  $request
     * @return Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function show($id)
    {
        //
        redirect::to();
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  Request  $request
     * @param  int  $id
     * @return Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function destroy($id)
    {
        //
    }
}
