<?php
/**
 * Created by PhpStorm.
 * User: Shahin
 * Date: 9/15/15
 * Time: 1:18 PM
 */
?>
@extends('layouts.frontend.frontend')
<title>{{ trans('lang.home') }}</title>
@section('content')
<div class="content container">
<div class="page-wrapper">
<header class="page-heading clearfix">
    <h1 class="heading-title pull-left">Career</h1>
</header>
<div class="page-content">
<div class="row page-row">
<div class="content-wrapper col-md-10 col-sm-8">
<div class="page-row">
<div class="table-responsive">
    <table class="table table-bordered">
        <thead>
        <tr>
            <th>#</th>
            <th>Date</th>
            <th>Title</th>
            <th>Action</th>
        </tr>
        </thead>
        <tbody>
        <?php $count = 1;?>
        @foreach($data as $value)
        {{--*/$title = 'job_title_'.$lang  /*--}}
        <tr>
            <td>{{$count}}</td>
            <td>{{$value->posting_date}}</td>
            <td>{{$value->$title}}</td>
            <td><a href="{{URL::to('filecareer/'.$value->id)}}"><span class="label label-success">Download</span></a></td>
        </tr>
       <?php $count++;?>
        @endforeach

        </tbody>
    </table><!--//table-->


</div><!--//table-responsive-->

</div><!--//page-row-->
</div><!--//content-wrapper-->
</div><!--//page-row-->
</div><!--//page-content-->
</div><!--//page-->
</div><!--//content-->

@stop
