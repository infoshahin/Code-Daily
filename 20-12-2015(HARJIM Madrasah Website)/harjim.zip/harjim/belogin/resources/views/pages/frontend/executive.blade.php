@extends('layouts.frontend.frontend')
<title>{{ trans('lang.home') }}</title>
@section('content')
 <div class="content container">
            <div class="page-wrapper">
                <header class="page-heading clearfix">
                    <h1 class="heading-title pull-left">Executive Councile</h1>

                </header> 
                <div class="page-content">                 
                    <div class="row page-row">                     
                        <div class="team-wrapper col-md-8 col-sm-7">
                        @foreach($executive as $value)        
                            <div class="row page-row " >
                                <figure class="thumb col-md-3 col-sm-4 col-xs-6">
                                {!! HTML::image('belogin/public/images/executive'.$value->image, 'a picture', array('class'=>'img-responsive')) !!}

                                </figure>
                                <div class="details col-md-9 col-sm-8 col-xs-6">
                                	{{--*/$name = 'name_'.$lang  /*--}}
                                	{{--*/$designation = 'designation_'.$lang  /*--}}
                                	{{--*/$details = 'details_'.$lang  /*--}}
                                    <h3 class="title">{{$value->$name}}</h3>
                                    <h4>{{$value->$designation}}</h4>
                                    <p>
                                    	{{$value->$details}}
                                    </p>                                 
                                </div>                               
                            </div>
                           @endforeach
                        </div><!--//team-wrapper-->

                    </div><!--//page-row-->
                </div><!--//page-content-->
            </div><!--//page--> 
        </div><!--//content-->

@stop