@extends('layouts.frontend.frontend')
<title>{{ trans('lang.home') }}</title>
@section('content')
<div class="content container">
            <div id="promo-slider" class="slider flexslider">
                <ul class="slides">
                @foreach($SliderImage as $value)
                    <li>
                    {!! HTML::image('belogin/public/slider_uploads/'.$value->file, 'a picture', array('width' => '1024px','height' => '350px')) !!}

                       {{--*/$caption = 'caption_'.$lang  /*--}}
                        <p class="flex-caption">
                            <span class="main" >{{$value->$caption}}</span>                          
                        </p>
                    </li>
                   @endforeach
                </ul><!--//slides-->
            </div><!--//flexslider-->
          

            <div class="row cols-wrapper">
                <div class="col-md-3">
                    <section class="events">
                        <h1 class="section-heading text-highlight"><span class="line">Event</span></h1>
                        <div class="section-content">
                        @foreach($Event as $eventValue)
                         {{--*/$event_name = 'event_name_'.$lang  /*--}}
                          {{--*/$event_description = 'event_description_'.$lang  /*--}}   
                            <div class="event-item">
                                <p class="date-label">
                                    <span class="month">
                                    <?php
                                    $date = $eventValue->event_from;
                                    $eventMonth = explode("-", $date);
                                    $eventMonth[1];
                                    switch ($eventMonth[1]) {
                                        case 1:
                                            echo "JAN";
                                            break;
                                        case 2:
                                            echo "FEB";
                                            break;
                                         case 3:
                                            echo "MAR";
                                            break;                                        
                                        case 4:
                                            echo "APR";
                                            break;
                                         case 5:
                                            echo "MAY";
                                            break;
                                         case 6:
                                            echo "JUN";
                                            break;
                                             case 7:
                                            echo "JUL";
                                            break;
                                        case 8:
                                            echo "AUG";
                                            break;
                                         case 9:
                                            echo "SEP";
                                            break;                                        
                                        case 10:
                                            echo "OCT";
                                            break;
                                         case 11:
                                            echo "NOV";
                                            break;
                                         case 12:
                                            echo "DEC";
                                            break;
                                        default:
                                            # code...
                                            break;
                                    }
                                    ?>
                                    </span>
                                    <span class="date-number"> 
                                    <?php                                   
                                   echo $eventMonth[2];
                                    ?></span>
                                </p>
                                <div class="details">
                                    <h2 class="title">{{$eventValue->$event_name}}</h2>
                                    <p class="time">{{$eventValue->$event_description}}</p>                            
                                </div><!--//details-->
                            </div><!--event-item-->  

                        @endforeach
                            
                            <a class="read-more" href="events.html">All events<i class="fa fa-chevron-right"></i></a>
                        </div><!--//section-content-->
                    </section><!--//events-->
                     <section class="links">
                        <h1 class="section-heading text-highlight"><span class="line">Visitor Counter</span></h1>
                        <div class="section-content">
                     <img src="http://www.e-zeeinternet.com/count.php?page=1121624&style=default&nbdigits=5" alt="Visitor Counter" border="0" >
                        </div><!--//section-content-->
                    </section><!--//links-->
                </div><!--//col-md-3-->
                <div class="col-md-6">
                    <section class="course-finder" style="padding:16px;">
                        <h1 class="section-heading text-highlight"><span class="line"></span></h1>
                        <article class="news-item page-row has-divider clearfix row">       
                                <figure class="thumb col-md-2 col-sm-3 col-xs-4">
                                <!-- {!! HTML::image('assets/images/news/news-thumb-1.jpg', 'a picture', array('class' => 'img-responsive')) !!} -->
                                 
                                </figure>
                                <div class="details col-md-10 col-sm-9 col-xs-8">
                                    <h3 class="title"><a href="news-single.html">History of School</a></h3>
                                    <p>Our school is established in 1985. Mr. XYZ was the founder of this school. His excellent contribution leads to the ultimate success of this what we are getting today. This school is contributing to the cultural refreshment and development of this area. This school has many historical engagements. There are many successful persons who are contributing in the national level were our students.

This school has tremendous reputation in social developments. Students come here not only to learn but to be enlightened and skilled.

                                    </p>
                                    <a class="btn btn-theme col-sm-3  read-more" href="news-single.html">Read More<i class="fa fa-chevron-right"></i></a>
                                </div>
                            </article>
                    </section><!--//course-finder-->

                     <section class="course-finder" style="padding:16px;">
                        <article class="news-item page-row has-divider clearfix row">       
                                <figure class="thumb col-md-2 col-sm-3 col-xs-4">
                                   {!! HTML::image('assets/images/news/news-thumb-1.jpg', 'a picture', array('class' => 'img-responsive')) !!}
                                </figure>
                                <div class="details col-md-10 col-sm-9 col-xs-8">
                                    <h3 class="title"><a href="news-single.html">Chairman of Executive Council</a></h3>
                                    <p>There is no alternative of education. I am really proud to be a part of this school. This school is not only famous for its results but also its history and discipline. Hopefully, one day, this school will be the best school in Bangladesh. We are dedicatedly working on it.

I wish every success of this school!

Thanks

Chairman
Executive Council
School Name 
</p>
                                    <a class="btn btn-theme col-sm-3  read-more" href="news-single.html">Read More<i class="fa fa-chevron-right"></i></a>
                                </div>
                            </article>
                    </section><!--//course-finder-->


                


                </div>
                <div class="col-md-3">



                                    <section class="testimonials">
                        <h1 class="section-heading text-highlight"><span class="line">Principal’s Speech</span></h1>
                    <!--     <div class="carousel-controls">
                            <a class="prev" href="#testimonials-carousel" data-slide="prev"><i class="fa fa-caret-left"></i></a>
                            <a class="next" href="#testimonials-carousel" data-slide="next"><i class="fa fa-caret-right"></i></a>
                        </div><!--//carousel-controls--> 
                        <div class="section-content">
                            <div id="testimonials-carousel" class="testimonials-carousel carousel slide">
                                <div class="carousel-inner">
                                    <div class="item active">
                                        <blockquote class="quote">                                  
                                            <p><i class="fa fa-quote-left"></i>
                                                {{--*/$speech = 'speech_'.$lang  /*--}}
                                              <?php echo $principalSpeech->$speech;?>

</p>
                                            <a class="read-more" href="{{URL::to($lang.'/principle')}}">Read More<i class="fa fa-chevron-right"></i></a>
                                        </blockquote>                
                                        <div class="row">
                                            <p class="people col-md-8 col-sm-3 col-xs-8"><span class="name">Principal</span><br /><span class="title">School Name </span></p>
                                            <!-- {!! HTML::image('assets/images/testimonials/profile-1.png', 'a picture', array('class' => 'profile col-md-4 pull-right')) !!} -->

                                        </div>                               
                                    </div><!--//item-->
                                   
                                    
                                </div><!--//carousel-inner-->
                            </div><!--//testimonials-carousel-->
                        </div><!--//section-content-->
                    </section><!--//testimonials-->
                    <section class="links">
                        <h1 class="section-heading text-highlight"><span class="line">Important Links</span></h1>
                        <div class="section-content">
                            @foreach($weblink as $valueWeb)
                            {{--*/$titile = 'weblink_title_'.$lang  /*--}}
                            <p><a href="{{$valueWeb->weblink_url}}"  target="_blank"><i class="fa fa-caret-right"></i>{{$valueWeb->$titile}}</a></p>
                            @endforeach
                        </div><!--//section-content-->
                    </section><!--//links-->



                </div><!--//col-md-3-->
            </div><!--//cols-wrapper-->
                       
            <section class="promo box box-dark">        
                <div class="col-md-9">
                <h1 class="section-heading">Why Our School</h1>
                    <p>This school is well reputed both in terms of results and well organized system. It follows proper academic curriculum and maintain academic calendar. Both teachers and students find this school a real place to spread the light of knowledge.
This school has consistently been top performer in Comilla Education Board and committed to sustain it. This school will facilitate you from every sphere as possible. We feel proud to invite you at our school.
</p>   
                </div>  
                <div class="col-md-3">
                    <a class="btn btn-cta" href="#"><i class="fa fa-play-circle"></i>Apply Online</a>  
                </div>
            </section><!--//promo-->
        </div>

@stop