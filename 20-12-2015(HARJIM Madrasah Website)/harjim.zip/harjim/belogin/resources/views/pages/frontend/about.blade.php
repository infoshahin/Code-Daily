@extends('layouts.frontend.frontend')
<title>{{ trans('lang.home') }}</title>
@section('content')
 <div class="content container">
            <div class="page-wrapper">
                <header class="page-heading clearfix">
                    <h1 class="heading-title pull-left">
                        {{--*/$title = 'title_'.$lang  /*--}}
                        <?php echo $data->$title;?></h1>
                    <div class="breadcrumbs pull-right">
                        <ul class="breadcrumbs-list">
                            <li class="breadcrumbs-label">You are here:</li>
                            <li><a href="{{URL::to($lang.'/home')}}">{{ trans('lang.home') }}</a><i class="fa fa-angle-right"></i></li>
                            <li class="current">{{ trans('lang.aboutus') }}</li>
                        </ul>
                    </div><!--//breadcrumbs-->
                </header>
                <div class="page-content">
                    <div class="row page-row">
                        <article class="welcome col-md-8 col-sm-7">

                            <h3 class="title">{{ trans('lang.about_history_title') }}</h3>

                            {{--*/$description = 'description_'.$lang  /*--}}
                            <p>
                               <?php echo $data->$description;?>
                            </p>

                        </article><!--//page-content-->

                    </div><!--//page-row-->
                </div><!--//page-content-->
            </div><!--//page-->
        </div><!--//content-->

@stop