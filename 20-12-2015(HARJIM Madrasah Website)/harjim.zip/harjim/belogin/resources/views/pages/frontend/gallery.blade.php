<?php
/**
 * Created by PhpStorm.
 * User: Shahin
 * Date: 9/15/15
 * Time: 1:18 PM
 */
?>
@extends('layouts.frontend.frontend')
<title>{{ trans('lang.home') }}</title>
@section('content')
<div class="content container">
    <div class="page-wrapper">
        <header class="page-heading clearfix">
            <h1 class="heading-title pull-left">{{ trans('lang.gellerymenu') }}</h1>

        </header>
        <div class="page-content">
            <div class="row page-row">
                @foreach($images as $value)
                {{--*/$caption = 'caption_'.$lang  /*--}}
                <a class="prettyphoto col-md-3 col-sm-3 col-xs-6" rel="prettyPhoto[gallery]" title="{{$value->$caption}}" href="{{URL::to('belogin/public/gallery_uploads/'.$value->file)}}">
                    {!! HTML::image('belogin/public/gallery_uploads/'.$value->file, $value->$caption, array('class' => 'img-responsive img-thumbnail')) !!}
                </a>
                @endforeach
                {!! $images->render() !!}
            </div><!--//page-row-->
        </div><!--//page-content-->
    </div><!--//page-->
</div><!--//content-->

@stop
