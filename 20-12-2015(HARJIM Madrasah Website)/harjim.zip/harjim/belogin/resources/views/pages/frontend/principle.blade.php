@extends('layouts.frontend.frontend')
<title>{{ trans('lang.home') }}</title>
@section('content')
 <div class="content container">
            <div class="page-wrapper">
                <header class="page-heading clearfix">
                    <h1 class="heading-title pull-left">
                        {{--*/$title = 'speech_title_en'.$lang  /*--}}
                        <?php echo $data->$title;?></h1>

                </header>
                <div class="page-content">
                    <div class="row page-row">
                        <article class="welcome col-md-8 col-sm-7">


                            {{--*/$description = 'speech_'.$lang  /*--}}
                            <p>
                               <?php echo $data->$description;?>
                            </p>

                        </article><!--//page-content-->

                    </div><!--//page-row-->
                </div><!--//page-content-->
            </div><!--//page-->
        </div><!--//content-->

@stop