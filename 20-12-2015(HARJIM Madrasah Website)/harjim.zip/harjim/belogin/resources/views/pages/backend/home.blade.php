<?php
use Illuminate\Support\Facades\Auth;
?>
@extends('layouts.backend.backend')
 @section('content')
 <div class="dev-page-content">                    
                    <!-- page content container -->
                    <div class="container">
                        

                        <div class="row">
                            <div class="col-md-12">

                                <div class="wrapper padding-bottom-0">
                                    <div class="dev-table">
                                        <div class="dev-col">
                                            <div class="dev-widget dev-widget-transparent">
                                 <center>   <h1>Welcome to Smart Study<br> Admin Username is : {{Auth::user()->username}}</h1></center>
                                           </div>

                                        </div>
                                    </div>
                                </div>


                            </div>
                        </div>
                        


                    </div>
                    <!-- ./page content container -->
                                        
                </div>

@stop