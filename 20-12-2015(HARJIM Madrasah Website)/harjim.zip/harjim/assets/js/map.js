var map;
jQuery(document).ready(function(){

    map = new GMaps({
        div: '#map',
        lat:  23.738983959216146,
        lng: 90.41515811043092,
    });
    map.addMarker({
        lat:  23.738983959216146,
        lng: 90.41515811043092,
        title: 'Address',      
        infoWindow: {
            content: '<h5 class="title">Belogin Technology Ltd.</h5><p><span class="region">Address line goes here</span><br><span class="postal-code">Postcode</span><br><span class="country-name">Country</span></p>'
        }
        
    });

});