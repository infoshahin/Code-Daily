﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MonitoringApps.MonitoringPanel
{
    public partial class Default : System.Web.UI.Page
    {
     
        protected void Page_Load(object sender, EventArgs e)
        {
            //GenerateBracInfo();
            //GenerateEblInboxInfo();
            //GenerateEblInboxBulkInfo();
            //GenerateISMSNewInfo();
            //GenerateISMSOldInfo();
        }

        private void GenerateBracInfo()
        {
            try
            {
                string mainDirectory = AppDomain.CurrentDomain.BaseDirectory;
                StreamReader streamReader = new StreamReader(mainDirectory + "//DbConfig//BracBank//config.txt");
                StreamReader streamReader2 = new StreamReader(mainDirectory + "//DbConfig//BracBank//Tables/sms_info_unprocessed.txt");
                var sendingStatus = streamReader2.ReadLine();
                var telPrefix = streamReader2.ReadLine();
                var count = streamReader2.ReadLine();

                MySqlConnection dbConnection = new MySqlConnection("server=" + streamReader.ReadLine() + ";Initial Catalog=" + streamReader.ReadLine() + ";Uid=" + streamReader.ReadLine() + ";Pwd=" + streamReader.ReadLine() + "");

                dbConnection.Open();
                MySqlCommand cmd = dbConnection.CreateCommand();
                cmd.CommandText = "SELECT " + sendingStatus + "," + telPrefix + "," + count + " FROM  sms_info_unprocessed WHERE " + sendingStatus + " !='SUCCESS' GROUP BY  " + sendingStatus + "," + telPrefix + "";
                MySqlDataReader dataReader = cmd.ExecuteReader();

                while (dataReader.Read())
                {
                    TableRow tableRow = new TableRow();
                    TableCell tableCell1 = new TableCell();
                    tableCell1.Controls.Add(new Literal { Text = "<a href = './Details.aspx?status=" + dataReader.GetString(0) + "&telprefix=" + dataReader.GetString(1) + "&tlcode=bbl' target ='blank'>" + dataReader.GetString(0) + "</a>" });
                    TableCell tableCell2 = new TableCell();
                    tableCell2.Text = dataReader.GetString(1);
                    TableCell tableCell3 = new TableCell();
                    tableCell3.Text = dataReader.GetInt32(2).ToString();
                    tableRow.Cells.Add(tableCell1);
                    tableRow.Cells.Add(tableCell2);
                    tableRow.Cells.Add(tableCell3);
                    BracTable.Rows.Add(tableRow);
                }
                dbConnection.Close();
            }
            catch (Exception error)
            {
                throw new Exception(error.Message);
            }
        }

        
        private void GenerateEblInboxInfo()
        {
            try
            {
                string mainDirectory = AppDomain.CurrentDomain.BaseDirectory;
                StreamReader streamReader = new StreamReader(mainDirectory + "//DbConfig//EasternBank//config.txt");
                StreamReader streamReader2 = new StreamReader(mainDirectory + "//DbConfig//EasternBank//Tables/inbox.txt");
                var instatusReport = streamReader2.ReadLine();
                var noOfTry = streamReader2.ReadLine();
                var count = streamReader2.ReadLine();

                MySqlConnection dbConnection = new MySqlConnection("server=" + streamReader.ReadLine() + ";Initial Catalog=" + streamReader.ReadLine() + ";Uid=" + streamReader.ReadLine() + ";Pwd=" + streamReader.ReadLine() + "");

                dbConnection.Open();
                MySqlCommand cmd = dbConnection.CreateCommand();
                cmd.CommandText = "SELECT " + instatusReport + "," + noOfTry + "," + count + " FROM inbox WHERE " + instatusReport + " !='SUCCESS' GROUP BY  " + instatusReport + "," + noOfTry + "";
                MySqlDataReader dataReader = cmd.ExecuteReader();

                while (dataReader.Read())
                {
                    TableRow tableRow = new TableRow();
                    TableCell tableCell1 = new TableCell();
                    tableCell1.Controls.Add(new Literal { Text = "<a href = './Details.aspx?status=" + dataReader.GetString(0) + "&try=" + dataReader.GetString(1) + "&tlcode=eblinbox' target ='blank'>" + dataReader.GetString(0) + "</a>" });
                    TableCell tableCell2 = new TableCell();
                    tableCell2.Text = dataReader.GetString(1);
                    TableCell tableCell3 = new TableCell();
                    tableCell3.Text = dataReader.GetInt32(2).ToString();
                    tableRow.Cells.Add(tableCell1);
                    tableRow.Cells.Add(tableCell2);
                    tableRow.Cells.Add(tableCell3);
                    EblInboxTable.Rows.Add(tableRow);
                }
                dbConnection.Close();
            }
            catch (Exception error)
            {
                throw new Exception(error.Message);
            }
        }

        private void GenerateEblInboxBulkInfo()
        {
            try
            {
                string mainDirectory = AppDomain.CurrentDomain.BaseDirectory;
                StreamReader streamReader = new StreamReader(mainDirectory + "//DbConfig//EasternBank//config.txt");
                StreamReader streamReader2 = new StreamReader(mainDirectory + "//DbConfig//EasternBank//Tables/inbox_bulk.txt");
                var instatusReport = streamReader2.ReadLine();
                var noOfTry = streamReader2.ReadLine();
                var count = streamReader2.ReadLine();

                MySqlConnection dbConnection = new MySqlConnection("server=" + streamReader.ReadLine() + ";Initial Catalog=" + streamReader.ReadLine() + ";Uid=" + streamReader.ReadLine() + ";Pwd=" + streamReader.ReadLine() + "");

                dbConnection.Open();
                MySqlCommand cmd = dbConnection.CreateCommand();
                cmd.CommandText = "SELECT " + instatusReport + "," + noOfTry + "," + count + " FROM  inbox_bulk WHERE " + instatusReport + " !='SUCCESS' GROUP BY  " + instatusReport + "," + noOfTry + "";
                MySqlDataReader dataReader = cmd.ExecuteReader();

                while (dataReader.Read())
                {
                    TableRow tableRow = new TableRow();
                    TableCell tableCell1 = new TableCell();
                    tableCell1.Controls.Add(new Literal { Text = "<a href = './Details.aspx?status=" + dataReader.GetString(0) + "&try=" + dataReader.GetString(1) + "&tlcode=eblbulk' target ='blank'>" + dataReader.GetString(0) + "</a>" });
                    TableCell tableCell2 = new TableCell();
                    tableCell2.Text = dataReader.GetString(1);
                    TableCell tableCell3 = new TableCell();
                    tableCell3.Text = dataReader.GetInt32(2).ToString();
                    tableRow.Cells.Add(tableCell1);
                    tableRow.Cells.Add(tableCell2);
                    tableRow.Cells.Add(tableCell3);
                    EblInboxBulkTable.Rows.Add(tableRow);
                }
                dbConnection.Close();
            }
            catch (Exception error)
            {
                throw new Exception(error.Message);
            }
        }

        private void GenerateISMSNewInfo()
        {
            try
            {
                string mainDirectory = AppDomain.CurrentDomain.BaseDirectory;
                StreamReader streamReader = new StreamReader(mainDirectory + "//DbConfig//iSMS_New//config.txt");
                StreamReader streamReader2 = new StreamReader(mainDirectory + "//DbConfig//iSMS_New//Tables/isms_data.txt");
                var smsStatus = streamReader2.ReadLine();
                var stakeholder = streamReader2.ReadLine();
                var count = streamReader2.ReadLine();

                MySqlConnection dbConnection = new MySqlConnection("server=" + streamReader.ReadLine() + ";Initial Catalog=" + streamReader.ReadLine() + ";Uid=" + streamReader.ReadLine() + ";Pwd=" + streamReader.ReadLine() + "");

                dbConnection.Open();
                MySqlCommand cmd = dbConnection.CreateCommand();
                cmd.CommandText = "SELECT " + smsStatus + "," + stakeholder + "," + count + " FROM  isms_data WHERE " + smsStatus + " !='SUCCESS' GROUP BY  " + smsStatus + "," + stakeholder + "";
                MySqlDataReader dataReader = cmd.ExecuteReader();

                while (dataReader.Read())
                {
                    TableRow tableRow = new TableRow();
                    TableCell tableCell1 = new TableCell();
                    tableCell1.Controls.Add(new Literal { Text = "<a href = './Details.aspx?status=" + dataReader.GetString(0) + "&stakeholder=" + dataReader.GetString(1) + "&tlcode=ismsnew' target ='blank'>" + dataReader.GetString(0) + "</a>" });
                    TableCell tableCell2 = new TableCell();
                    tableCell2.Text = dataReader.GetString(1);
                    TableCell tableCell3 = new TableCell();
                    tableCell3.Text = dataReader.GetInt32(2).ToString();
                    tableRow.Cells.Add(tableCell1);
                    tableRow.Cells.Add(tableCell2);
                    tableRow.Cells.Add(tableCell3);
                    ISmsNewTable.Rows.Add(tableRow);
                }
                dbConnection.Close();
            }
            catch (Exception error)
            {
                throw new Exception(error.Message);
            }
        }

        private void GenerateISMSOldInfo()
        {
            try
            {
                string mainDirectory = AppDomain.CurrentDomain.BaseDirectory;
                StreamReader streamReader = new StreamReader(mainDirectory + "//DbConfig//iSMS_Old//config.txt");
                StreamReader streamReader2 = new StreamReader(mainDirectory + "//DbConfig//iSMS_Old//Tables/isms_data.txt");
                var smsStatus = streamReader2.ReadLine();
                var stakeholder = streamReader2.ReadLine();
                var count = streamReader2.ReadLine();

                MySqlConnection dbConnection = new MySqlConnection("server=" + streamReader.ReadLine() + ";Initial Catalog=" + streamReader.ReadLine() + ";Uid=" + streamReader.ReadLine() + ";Pwd=" + streamReader.ReadLine() + "");

                dbConnection.Open();
                MySqlCommand cmd = dbConnection.CreateCommand();
                cmd.CommandText = "SELECT " + smsStatus + "," + stakeholder + "," + count + " FROM  isms_data_old WHERE " + smsStatus + " !='SUCCESS' GROUP BY  " + smsStatus + "," + stakeholder + "";
                MySqlDataReader dataReader = cmd.ExecuteReader();

                while (dataReader.Read())
                {
                    TableRow tableRow = new TableRow();
                    TableCell tableCell1 = new TableCell();
                    tableCell1.Controls.Add(new Literal { Text = "<a href = './Details.aspx?status=" + dataReader.GetString(0) + "&stakeholder=" + dataReader.GetString(1) + "&tlcode=ismsold' target ='blank'>" + dataReader.GetString(0) + "</a>" });
                    TableCell tableCell2 = new TableCell();
                    tableCell2.Text = dataReader.GetString(1);
                    TableCell tableCell3 = new TableCell();
                    tableCell3.Text = dataReader.GetInt32(2).ToString();
                    tableRow.Cells.Add(tableCell1);
                    tableRow.Cells.Add(tableCell2);
                    tableRow.Cells.Add(tableCell3);
                    ISmsOldTable.Rows.Add(tableRow);
                }
                dbConnection.Close();
            }
            catch (Exception error)
            {
                throw new Exception(error.Message);
            }
        }

        protected void BracBankTab_Click(object sender, EventArgs e)
        {
            GenerateBracInfo();
        }

        protected void EblInboxTab_Click(object sender, EventArgs e)
        {
            GenerateEblInboxInfo();
        }

        protected void EblInboxBulkTab_Click(object sender, EventArgs e)
        {
            GenerateEblInboxBulkInfo();
        }

        protected void IsmsNewTab_Click(object sender, EventArgs e)
        {
            GenerateISMSNewInfo();
        }

        protected void IsmsOldTab_Click(object sender, EventArgs e)
        {
            GenerateISMSOldInfo();
        }
    }
}