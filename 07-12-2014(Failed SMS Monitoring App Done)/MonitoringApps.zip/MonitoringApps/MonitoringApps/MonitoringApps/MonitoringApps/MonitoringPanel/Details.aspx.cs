﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;

namespace MonitoringApps.MonitoringPanel
{
    public partial class Details : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {          
            string tlcode = Request.QueryString["tlcode"];

            if (tlcode == "bbl")
            {
                DetailBracBank();
            }
            else if (tlcode == "eblinbox")
            {
                DetailEblInbox();
            }
            else if (tlcode == "eblbulk")
            {
                DetailEblInboxBulk();
            }
            else if (tlcode == "ismsnew")
            {
                DetailiSmsNew();
            }
            else if (tlcode == "ismsold")
            {
                DetailiSmsOld();
            }
        }

        private void DetailBracBank()
        {
            try
            {
                string mainDirectory = AppDomain.CurrentDomain.BaseDirectory;
                StreamReader streamReader = new StreamReader(mainDirectory + "//DbConfig//BracBank//config.txt");
                StreamReader streamReader2 = new StreamReader(mainDirectory + "//DbConfig//BracBank//Tables/sms_info_unprocessedDetails.txt");
                var sendingStatus = streamReader2.ReadLine();
                var msgType = streamReader2.ReadLine();
                var telPrefix = streamReader2.ReadLine();
                var noOfTry = streamReader2.ReadLine();
                var sendTime = streamReader2.ReadLine();
                var count = streamReader2.ReadLine();

                MySqlConnection dbConnection = new MySqlConnection("server=" + streamReader.ReadLine() + ";Initial Catalog=" + streamReader.ReadLine() + ";Uid=" + streamReader.ReadLine() + ";Pwd=" + streamReader.ReadLine() + "");
                MySqlDataAdapter dataAdapter = new MySqlDataAdapter("SELECT " + sendingStatus + "," + msgType + "," + telPrefix + "," + noOfTry + "," + sendTime + "," + count + " AS Total FROM sms_info_unprocessed WHERE " + sendingStatus + "= '" + Request.QueryString["status"] + "' AND " + telPrefix + "= '" + Request.QueryString["telprefix"] + "' GROUP BY " + sendingStatus + "," + telPrefix + " ORDER BY " + noOfTry + "", dbConnection);

                DataTable dataTable = new DataTable();
                dataAdapter.Fill(dataTable);
                DetailBracGridView.DataSource = dataTable.AsDataView();
                DetailBracGridView.DataBind();
            }
            catch (Exception error)
            {
                throw new Exception(error.Message);
            }
        }

        private void DetailEblInbox()
        {
            try
            {
                string mainDirectory = AppDomain.CurrentDomain.BaseDirectory;
                StreamReader streamReader = new StreamReader(mainDirectory + "//DbConfig//EasternBank//config.txt");
                StreamReader streamReader2 = new StreamReader(mainDirectory + "//DbConfig//EasternBank//Tables/inboxDetails.txt");
                var instatusReport = streamReader2.ReadLine();
                var telPrefix = streamReader2.ReadLine();
                var noOfTry = streamReader2.ReadLine();
                var sendingTime = streamReader2.ReadLine();
                var count = streamReader2.ReadLine();

                MySqlConnection dbConnection = new MySqlConnection("server=" + streamReader.ReadLine() + ";Initial Catalog=" + streamReader.ReadLine() + ";Uid=" + streamReader.ReadLine() + ";Pwd=" + streamReader.ReadLine() + "");
                MySqlDataAdapter dataAdapter = new MySqlDataAdapter("SELECT " + instatusReport + "," + telPrefix + "," + noOfTry + "," + sendingTime + "," + count + " AS Total FROM inbox WHERE " + instatusReport + "= '" + Request.QueryString["status"] + "' AND " + noOfTry + "= '" + Request.QueryString["try"] + "' GROUP BY " + instatusReport + "," + telPrefix + " ORDER BY " + sendingTime + "", dbConnection);
                
                DataTable dataTable = new DataTable();
                dataAdapter.Fill(dataTable);
                DetailEblInboxGridView.DataSource = dataTable.AsDataView();
                DetailEblInboxGridView.DataBind();
            }
            catch (Exception error)
            {
                throw new Exception(error.Message);
            }
        }

        private void DetailEblInboxBulk()
        {
            try
            {
                string mainDirectory = AppDomain.CurrentDomain.BaseDirectory;
                StreamReader streamReader = new StreamReader(mainDirectory + "//DbConfig//EasternBank//config.txt");
                StreamReader streamReader2 = new StreamReader(mainDirectory + "//DbConfig//EasternBank//Tables/inbox_bulkDetails.txt");
                var instatusReport = streamReader2.ReadLine();
                var telPrefix = streamReader2.ReadLine();
                var noOfTry = streamReader2.ReadLine();
                var sendingTime = streamReader2.ReadLine();
                var count = streamReader2.ReadLine();

                MySqlConnection dbConnection = new MySqlConnection("server=" + streamReader.ReadLine() + ";Initial Catalog=" + streamReader.ReadLine() + ";Uid=" + streamReader.ReadLine() + ";Pwd=" + streamReader.ReadLine() + "");
                MySqlDataAdapter dataAdapter = new MySqlDataAdapter("SELECT " + instatusReport + "," + telPrefix + "," + noOfTry + "," + sendingTime + "," + count + " AS Total FROM inbox_bulk WHERE " + instatusReport + "= '" + Request.QueryString["status"] + "' AND " + noOfTry + "= '" + Request.QueryString["try"] + "' GROUP BY " + instatusReport + "," + telPrefix + " ORDER BY " + sendingTime + "", dbConnection);

                DataTable dataTable = new DataTable();
                dataAdapter.Fill(dataTable);
                DetailEblInboxBulkGridView.DataSource = dataTable.AsDataView();
                DetailEblInboxBulkGridView.DataBind();
            }
            catch (Exception error)
            {
                throw new Exception(error.Message);
            }
        }

        private void DetailiSmsNew()
        {
            try
            {
                string mainDirectory = AppDomain.CurrentDomain.BaseDirectory;
                StreamReader streamReader = new StreamReader(mainDirectory + "//DbConfig//iSMS_New//config.txt");
                StreamReader streamReader2 = new StreamReader(mainDirectory + "//DbConfig//iSMS_New//Tables/isms_dataDetails.txt");
                var smsStatus = streamReader2.ReadLine();
                var stakeholder = streamReader2.ReadLine();
                var noOfTry = streamReader2.ReadLine();
                var count = streamReader2.ReadLine();

                MySqlConnection dbConnection = new MySqlConnection("server=" + streamReader.ReadLine() + ";Initial Catalog=" + streamReader.ReadLine() + ";Uid=" + streamReader.ReadLine() + ";Pwd=" + streamReader.ReadLine() + "");
                MySqlDataAdapter dataAdapter = new MySqlDataAdapter("SELECT " + smsStatus + "," + stakeholder + "," + noOfTry + "," + count + " AS Total FROM isms_data WHERE " + smsStatus + "= '" + Request.QueryString["status"] + "' AND " + stakeholder + "= '" + Request.QueryString["stakeholder"] + "' GROUP BY " + smsStatus + "," + stakeholder + " ORDER BY " + noOfTry + "", dbConnection);

                DataTable dataTable = new DataTable();
                dataAdapter.Fill(dataTable);
                DetailISmsNewGridView.DataSource = dataTable.AsDataView();
                DetailISmsNewGridView.DataBind();
            }
            catch (Exception error)
            {
                throw new Exception(error.Message);
            }
        }

        private void DetailiSmsOld()
        {
            try
            {
                string mainDirectory = AppDomain.CurrentDomain.BaseDirectory;
                StreamReader streamReader = new StreamReader(mainDirectory + "//DbConfig//iSMS_Old//config.txt");
                StreamReader streamReader2 = new StreamReader(mainDirectory + "//DbConfig//iSMS_Old//Tables/isms_dataDetails.txt");
                var smsStatus = streamReader2.ReadLine();
                var stakeholder = streamReader2.ReadLine();
                var noOfTry = streamReader2.ReadLine();
                var count = streamReader2.ReadLine();

                MySqlConnection dbConnection = new MySqlConnection("server=" + streamReader.ReadLine() + ";Initial Catalog=" + streamReader.ReadLine() + ";Uid=" + streamReader.ReadLine() + ";Pwd=" + streamReader.ReadLine() + "");
                MySqlDataAdapter dataAdapter = new MySqlDataAdapter("SELECT " + smsStatus + "," + stakeholder + "," + noOfTry + "," + count + " AS Total FROM isms_data_old WHERE " + smsStatus + "= '" + Request.QueryString["status"] + "' AND " + stakeholder + "= '" + Request.QueryString["stakeholder"] + "' GROUP BY " + smsStatus + "," + stakeholder + " ORDER BY " + noOfTry + "", dbConnection);

                DataTable dataTable = new DataTable();
                dataAdapter.Fill(dataTable);
                DetailISmsNOldGridView.DataSource = dataTable.AsDataView();
                DetailISmsNOldGridView.DataBind();
            }
            catch (Exception error)
            {
                throw new Exception(error.Message);
            }
        }
    }
}