<?php echo
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header('Content-Type: text/html');?>

<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->  
<!--[if IE 9]> <html lang="en" class="ie9"> <![endif]-->  
<!--[if !IE]><!--> <html lang="en"> <!--<![endif]-->  


<head>
    
    <!-- Meta -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">    
    <link rel="shortcut icon" href="favicon.ico">  
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700' rel='stylesheet' type='text/css'>   
    <!-- Global CSS -->
     {!! HTML::style('assets/plugins/bootstrap/css/bootstrap.min.css') !!}       
     
    <!-- Plugins CSS -->    
    {!! HTML::style('assets/plugins/font-awesome/css/font-awesome.css') !!}     
     {!! HTML::style('assets/plugins/flexslider/flexslider.css') !!} 
       {!! HTML::style('assets/plugins/pretty-photo/css/prettyPhoto.css') !!} 
 
    <!-- Theme CSS -->  
    
       {!! HTML::style('assets/css/styles.css') !!} 
    
    <style type="text/css">
    body{
        background-color:#ffff;
    }
    .header .top-bar {
    background: white;
}
.main-nav {
    background: #007700;
    margin-bottom: 30px;
}
.footer {
    background: #007700;
    color: #fff;
}
/*.main-nav .nav .nav-item.active > a {
    background: red;
    color: #fff;
}*/
.home-page section {
    background: #FFFF;
    overflow: hidden;
    margin-bottom: 30px;
}
/*.footer .bottom-bar {
    background: #dadada;
    padding: 5px 0;
}*/
.box.box-dark {
    background: #007700;
    color: #fff;
}
a.btn-cta, .btn-cta {
    background: #27ae60;
    color: #fff;
    padding: 10px 20px;
    font-size: 18px;
    line-height: 1.33;
    -webkit-border-radius: 0;
    -moz-border-radius: 0;
    -ms-border-radius: 0;
    -o-border-radius: 0;
    border-radius: 0;
    -moz-background-clip: padding;
    -webkit-background-clip: padding-box;
    background-clip: padding-box;
    border: 1px solid white;
    font-family: 'open sans', arial, sans-serif;
}
.home-page h1.section-heading .line {
    border-top: 2px solid green;
    display: inline-block;
    padding: 0 15px;
    padding-top: 5px;
}

.date-label .month {
    background: #27ae60;
    color: #fff;
    display: block;
    font-size: 13px;
    text-transform: uppercase;
}
#topcontrol {
    background: #27ae60;
}
.flexslider .slides .flex-caption .main {    
    background: #D1B315;  
}
.btn-theme {
    background: #27ae60;
    border: 1px solid;
    color: #fff;
}
.flexslider .slides .flex-caption .main {
    background: #27ae60;
}
.footer .footer-content .adr {
    margin-bottom: 30px;
    color: white;
}
.footer p {
    color: white;
}
.fa-map-marker:before {
    content: "\f041";
    color: white;
}
.fa-phone:before {
    content: "\f095";
    color: white;
}
.fa-envelope:before {
    content: "\f0e0";
    color: white;
}


.pull-right .fa-phone:before {
    content: "\f095";
    /* color: black; */
    color: green;
}
.pull-right .fa-envelope:before {
    content: "\f0e0";
    color: green;
}

.footer-col-inner .fa-caret-right:before {
    content: "\f0da";
    color: white;
}




.flexslider .slides .flex-caption .main {
    background: #27ae60;
    border: 1px solid white;
}
.flexslider .slides .flex-caption .secondary {
    display: inline-block;
    background: rgba(0, 0, 0, 0.8);
    padding: 5px 15px;
    color: #fff;
    font-size: 16px;
    border: 1px solid;
}

</style>
</head> 

<body class="home-page">
    <div class="wrapper">
        <!-- ******HEADER****** --> 
        <header class="header">  
            <div class="top-bar">
                <div class="container">              
                    
                    <form class="pull-right search-form" role="search">
                        <div class="form-group">
                            <input type="text" class="form-control" placeholder="Search the site...">
                        </div>
                        <button type="submit" class="btn btn-theme">Go</button>
                    </form>         
                </div>      
            </div><!--//to-bar-->
            <div class="header-main container">
                <h1 class="logo col-md-4 col-sm-4">
                    <a href="index-2.html">{!! HTML::image('assets/images/school2.png', 'Logo', array('id' => 'logo')) !!}</a>
                </h1><!--//logo-->           
                <div class="info col-md-8 col-sm-8">
                    <ul class="menu-top navbar-right hidden-xs">
                        <li class="divider"><a href="{{URL::to('bn/home')}}">Bangla</a></li>
                        <li class="divider"><a href="{{URL::to('en/home')}}">English</a></li>
                        <li class="divider"><a href="{{URL::to('admin')}}" target="_blank">Admin Login</a></li>
                        <li class="divider"><a href="faq.html">{{ trans('lang.faq') }}</a></li>
                        <li class="divider"><a href="faq.html">{{ trans('lang.implink') }}</a></li>
                        <li><a href="contact.html">{{ trans('lang.cereer') }}</a></li>
 </ul><!--//menu-top-->
                    <br />
                    <div class="contact pull-right">
                        <p class="phone"><i class="fa fa-phone"></i>{{ trans('lang.call') }}</p> 
                        <p class="email"><i class="fa fa-envelope"></i><a href="#">info@belogin.com</a></p>
                    </div><!--//contact-->
                </div><!--//info-->
            </div><!--//header-main-->
        </header><!--//header-->
        
        <!-- ******NAV****** -->
        <nav class="main-nav" role="navigation">
            <div class="container">
                <div class="navbar-header">
                    <button class="navbar-toggle" type="button" data-toggle="collapse" data-target="#navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button><!--//nav-toggle-->
                </div><!--//navbar-header-->            
                <div class="navbar-collapse collapse" id="navbar-collapse">
                    <ul class="nav navbar-nav">
                        <li class="active nav-item"><a href="{{URL::to($lang.'/home')}}">{{ trans('lang.home') }}</a></li>
                        <li class="nav-item dropdown">
                            <a class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-delay="0" data-close-others="false" href="#">{{ trans('lang.aboutus') }} <i class="fa fa-angle-down"></i></a>
                            <ul class="dropdown-menu">
                                <li><a href="{{URL::to($lang.'/history')}}">{{ trans('lang.aboutus_history') }}</a></li>
                                <li><a href="{{URL::to($lang.'/executive-body')}}">{{ trans('lang.executive') }}</a></li>
                                <li><a href="course-single-2.html">{{ trans('lang.principalmenu') }}</a></li>  
                                <!-- <li class="dropdown-submenu">
                                    <a class="trigger" tabindex="-1" href="#">Menu Levels <i class="fa fa-angle-right"></i></a>
                                    <ul class="dropdown-menu">
                                        <li><a tabindex="-1" href="#">Submenu Level 2</a></li>
                                        <li class="dropdown-submenu">
                                            <a class="trigger" href="#">Submenu Level 2 <i class="fa fa-angle-right"></i></a>
                                            <ul class="dropdown-menu">
                                                <li><a href="#">Submenu Level 3</a></li>
                                                <li><a href="#">Submenu Level 3</a></li>
                                            </ul>
                                        </li>
                                        <li><a href="#">Submenu Level 2</a></li>
                                        <li><a href="#">Submenu Level 2</a></li>
                                    </ul>
                                </li>       -->     
                            </ul>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-delay="0" data-close-others="false" href="#">{{ trans('lang.noticemenu') }} <i class="fa fa-angle-down"></i></a>
                            <ul class="dropdown-menu">
                                <li><a href="news.html"> {{ trans('lang.news') }}</a></li>
                                <li><a href="news-single.html">{{ trans('lang.event') }}</a></li>   
                                <li><a href="news-single-2.html">Demo Menu</a></li>          
                            </ul>
                        </li>
                        <li class="nav-item"><a href="events.html">{{ trans('lang.resultmenu') }}</a></li>
                        <li class="nav-item"><a href="events.html">{{ trans('lang.stdmenu') }}</a></li>
                        <li class="nav-item"><a href="events.html">{{ trans('lang.tecmenu') }}</a></li>
                         <li class="nav-item"><a href="events.html">{{ trans('lang.gellerymenu') }}</a></li>

                     <!--    <li class="nav-item dropdown">
                            <a class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-delay="0" data-close-others="false" href="#">{{ trans('lang.result') }} <i class="fa fa-angle-down"></i></a>
                            <ul class="dropdown-menu">
                                <li><a href="about.html">About</a></li>
                                <li><a href="team.html">Leadership Team</a></li>
                                <li><a href="jobs.html">Jobs</a></li>
                                <li><a href="job-single.html">Single Job</a></li>
                                <li><a href="gallery.html">Gallery (3 columns)</a></li>
                                <li><a href="gallery-2.html">Gallery (4 columns)</a></li>
                                <li><a href="gallery-3.html">Gallery (2 columns)</a></li>
                                <li><a href="gallery-4.html">Gallery (with sidebar)</a></li>
                                <li><a href="gallery-album.html">Single Gallery</a></li>
                                <li><a href="gallery-album-2.html">Single Gallery (with sidebar)</a></li>
                                <li><a href="faq.html">FAQ</a></li>                                
                                <li><a href="privacy.html">Privacy Policy</a></li> 
                                <li><a href="terms-and-conditions.html">Terms & Conditions</a></li>                   
                            </ul>
                        </li><!--//dropdown--> 
                       <!--  <li class="nav-item dropdown">
                            <a class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-delay="0" data-close-others="false" href="#">{{ trans('lang.students') }} <i class="fa fa-angle-down"></i></a>
                            <ul class="dropdown-menu">
                                <li><a href="typography.html"><i class="fa fa-file-text"></i> Typography</a></li>
                                <li><a href="tables.html"><i class="fa fa-table"></i> Tables</a></li>
                                <li><a href="buttons.html"><i class="fa fa-star"></i> Buttons</a></li>
                                <li><a href="components.html"><i class="fa fa-rocket"></i> Components</a></li> 
                                <li><a href="icons.html"><i class="fa fa-heart"></i> Icons</a></li>                                                 
                            </ul>
                        </li> --><!--//dropdown-->
                        <li class="nav-item"><a href="contact.html">{{ trans('lang.contact') }}</a></li>
                    </ul><!--//nav-->
                </div><!--//navabr-collapse-->
            </div><!--//container-->
        </nav><!--//main-nav-->
        
        <!-- ******CONTENT****** --> 

        @yield('content')

        <!--//content-->
    </div><!--//wrapper-->
    
    <!-- ******FOOTER****** --> 
    <footer class="footer">
        <div class="footer-content">
            <div class="container">
                <div class="row">
                <div class="footer-col col-md-3 col-sm-4 about">
                    <div class="footer-col-inner">
                        <h3>About</h3>
                        <ul>
                            <li><a href="about.html"><i class="fa fa-caret-right"></i>About us</a></li>
                            <li><a href="contact.html"><i class="fa fa-caret-right"></i>Contact us</a></li>
                            <li><a href="privacy.html"><i class="fa fa-caret-right"></i>Privacy policy</a></li>
                            <li><a href="terms-and-conditions.html"><i class="fa fa-caret-right"></i>Terms & Conditions</a></li>
                        </ul>
                    </div><!--//footer-col-inner-->
                </div><!--//foooter-col-->
                <div class="footer-col col-md-6 col-sm-8 newsletter">
                    <div class="footer-col-inner">
                        <h3>Join our e-Mail book</h3>
                        <p>Subscribe to get our special notice(s) sent directly to your inbox</p>
                        <form class="subscribe-form">
                            <div class="form-group">
                                <input type="email" class="form-control" placeholder="Enter your email" />
                            </div>
                            <input class="btn btn-theme btn-subscribe" type="submit" value="Subscribe">
                        </form>
                        
                    </div><!--//footer-col-inner-->
                </div><!--//foooter-col--> 
                <div class="footer-col col-md-3 col-sm-12 contact">
                    <div class="footer-col-inner">
                        <h3>Contact us</h3>
                        <div class="row">
                            <p class="adr clearfix col-md-12 col-sm-4">
                                <i class="fa fa-map-marker pull-left"></i>        
                                <span class="adr-group pull-left">       
                                    <span class="street-address">Our School</span><br>
                                    <span class="region">Address map</span><br>
                                    <span class="postal-code">Address</span><br>
                                    <span class="country-name">Bangladesh</span>
                                </span>
                            </p>
                            <p class="tel col-md-12 col-sm-4"><i class="fa fa-phone"></i>88 02 9343607</p>
                            <p class="email col-md-12 col-sm-4"><i class="fa fa-envelope"></i><a href="#">info@belogin.com</a></p>  
                        </div> 
                    </div><!--//footer-col-inner-->            
                </div><!--//foooter-col-->   
                </div>   
            </div>        
        </div><!--//footer-content-->
        <div class="bottom-bar">
            <div class="container">
                <div class="row">
                    <small class="copyright col-md-6 col-sm-12 col-xs-12">Copyright @ 2015 <a href="#">School</a> | Developed by: <a href="http://belogin.com/">Belogin</a></small>
                  
                    <ul class="social pull-right col-md-6 col-sm-12 col-xs-12">
                        <li><a href="#" ><i class="fa fa-facebook"></i></a></li>
                        <li><a href="#" ><i class="fa fa-linkedin"></i></a></li>
                        <li><a href="#"  class="row-end"><i class="fa fa-skype"></i></a></li> 
                    </ul><!--//social-->
                </div><!--//row-->
            </div><!--//container-->
        </div><!--//bottom-bar-->
    </footer><!--//footer-->
    
    <!-- *****CONFIGURE STYLE****** -->  
  
 
    <!-- Javascript -->          

       {!! HTML::script('assets/plugins/jquery-1.11.2.min.js') !!} 
       {!! HTML::script('assets/plugins/jquery-migrate-1.2.1.min.js') !!} 
       {!! HTML::script('assets/plugins/bootstrap/js/bootstrap.min.js') !!} 
       {!! HTML::script('assets/plugins/bootstrap-hover-dropdown.min.js') !!} 
       {!! HTML::script('assets/plugins/back-to-top.js') !!} 
       {!! HTML::script('assets/plugins/jquery-placeholder/jquery.placeholder.js') !!} 
       {!! HTML::script('assets/plugins/pretty-photo/js/jquery.prettyPhoto.js') !!} 
       {!! HTML::script('assets/plugins/flexslider/jquery.flexslider-min.js') !!} 
       {!! HTML::script('assets/plugins/jflickrfeed/jflickrfeed.min.js') !!} 
       {!! HTML::script('assets/js/main.js') !!} 
    
</body>


</html> 

