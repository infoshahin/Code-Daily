@extends('layouts.frontend.frontend')
<title>{{ trans('lang.home') }}</title>
@section('content')
<div class="content container">
            <div id="promo-slider" class="slider flexslider">
                <ul class="slides">
                    <li>
                    {!! HTML::image('assets/images/slides/slide-3.jpg') !!}
                       
                        <p class="flex-caption">
                            <span class="main" >Our Smart Library</span>
                            <br />
                            <span class="secondary clearfix" >Choose from over 2000 books</span>
                        </p>
                    </li>
                    <li>
                    {!! HTML::image('assets/images/slides/slide-2.jpg') !!}
                        
                        <p class="flex-caption">
                            <span class="main" >Find our digital contents</span>
                            <br />
                            <span class="secondary clearfix" >Download contents from e-Portal</span>
                        </p>
                    </li>
                    <li>
                    {!! HTML::image('assets/images/slides/slide-1.jpg') !!}
                        
                        <p class="flex-caption">
                            <span class="main" >Education Everywhere</span>
                            <br />
                            <span class="secondary clearfix" >Read books as per your convenience</span>
                        </p>
                    </li>
                 <!--    <li>
                    {!! HTML::image('assets/images/slides/slide-4.jpg') !!}
                        
                        <p class="flex-caption">
                            <span class="main" >Nam ultricies accumsan pellentesque</span>
                            <br />
                            <span class="secondary clearfix" >In justo orci, ornare vitae nulla sed, suscipit suscipit augue</span>
                        </p>
                    </li> -->
                </ul><!--//slides-->
            </div><!--//flexslider-->
          
            <section class="news">
                <h1 class="section-heading text-highlight"><span class="line">Latest News</span></h1>     
                <div class="carousel-controls">
                    <a class="prev" href="#news-carousel" data-slide="prev"><i class="fa fa-caret-left"></i></a>
                    <a class="next" href="#news-carousel" data-slide="next"><i class="fa fa-caret-right"></i></a>
                </div><!--//carousel-controls--> 
                <div class="section-content clearfix">
                    <div id="news-carousel" class="news-carousel carousel slide">
                        <div class="carousel-inner">
                            <div class="item active"> 
                                <div class="col-md-4 news-item">
                                    <h2 class="title"><a href="news-single.html">Inter school sports competition </a></h2>
                                   
                                   
                                    <p>Our school has participated in inter school sports competition and won first prize. This is truly great news for our school. We congratulate our boys. To celebrate this occasion, our school management has decided to arrange a party on September 05, 2015. Please join the program to make it successful. Find more information at academic office.</p>
                                    <a class="read-more" href="news-single.html">Read More<i class="fa fa-chevron-right"></i></a>                
                                </div><!--//news-item-->
                                <div class="col-md-4 news-item">
                                    <h2 class="title"><a href="news-single.html">SSC Exam 2015</a></h2>
                                    <p>Our school stood first in Secondary School Certificate (SSC) examination in 2015 from Comilla Education Board. We are pleased to announce this news. We are showing our gratitude to all the students, teachers, parents and school staffs. To find the result, please visit: http:// ourschool.edu.bd.</p>
                                    <a class="read-more" href="news-single.html">Read More<i class="fa fa-chevron-right"></i></a>
                                   
                                </div><!--//news-item-->
                                <div class="col-md-4 news-item">
                                    <h2 class="title"><a href="news-single.html">Annual picnic</a></h2>
                                    <p>Our school is going to arrange its annual picnic on December 30, 2015. We have selected Rangamati as the picnic destination. All the students are requested to collect the picnic ticket from academic office. If any guardian wants to go, then please contact us by December 15, 2015.</p>
                                    <a class="read-more" href="news-single.html">Read More<i class="fa fa-chevron-right"></i></a>
                                                              </div><!--//news-item-->
                            </div><!--//item-->
     <div class="item"> 
                                <div class="col-md-4 news-item">
                                    <h2 class="title"><a href="news-single.html">Inter school sports competition </a></h2>
                                   
                                   
                                    <p>Our school has participated in inter school sports competition and won first prize. This is truly great news for our school. We congratulate our boys. To celebrate this occasion, our school management has decided to arrange a party on September 05, 2015. Please join the program to make it successful. Find more information at academic office.</p>
                                    <a class="read-more" href="news-single.html">Read More<i class="fa fa-chevron-right"></i></a>                
                                </div><!--//news-item-->
                                <div class="col-md-4 news-item">
                                    <h2 class="title"><a href="news-single.html">SSC Exam 2015</a></h2>
                                    <p>Our school stood first in Secondary School Certificate (SSC) examination in 2015 from Comilla Education Board. We are pleased to announce this news. We are showing our gratitude to all the students, teachers, parents and school staffs. To find the result, please visit: http:// ourschool.edu.bd.</p>
                                    <a class="read-more" href="news-single.html">Read More<i class="fa fa-chevron-right"></i></a>
                                   
                                </div><!--//news-item-->
                                <div class="col-md-4 news-item">
                                    <h2 class="title"><a href="news-single.html">Annual picnic</a></h2>
                                    <p>Our school is going to arrange its annual picnic on December 30, 2015. We have selected Rangamati as the picnic destination. All the students are requested to collect the picnic ticket from academic office. If any guardian wants to go, then please contact us by December 15, 2015.</p>
                                    <a class="read-more" href="news-single.html">Read More<i class="fa fa-chevron-right"></i></a>
                                                              </div><!--//news-item-->
                            </div><!--//item-->
                        </div><!--//carousel-inner-->
                    </div><!--//news-carousel-->  
                </div><!--//section-content-->     
            </section><!--//news-->
            <div class="row cols-wrapper">
                <div class="col-md-3">
                    <section class="events">
                        <h1 class="section-heading text-highlight"><span class="line">Events</span></h1>
                        <div class="section-content">
                            <div class="event-item">
                                <p class="date-label">
                                    <span class="month">FEB</span>
                                    <span class="date-number">18</span>
                                </p>
                                <div class="details">
                                    <h2 class="title">Open Day</h2>
                                    <p class="time"><i class="fa fa-clock-o"></i>10:00am - 18:00pm</p>
                                    <p class="location"><i class="fa fa-map-marker"></i>East Campus</p>                            
                                </div><!--//details-->
                            </div><!--event-item-->  
                            <div class="event-item">
                                <p class="date-label">
                                    <span class="month">SEP</span>
                                    <span class="date-number">06</span>
                                </p>
                                <div class="details">
                                    <h2 class="title">E-learning </h2>
                                    <p class="time"><i class="fa fa-clock-o"></i>10:00am - 16:00pm</p>
                                    <p class="location"><i class="fa fa-map-marker"></i>Learning Center</p>                            
                                </div><!--//details-->
                            </div><!--event-item-->
                            <div class="event-item">
                                <p class="date-label">
                                    <span class="month">JUN</span>
                                    <span class="date-number">23</span>
                                </p>
                                <div class="details">
                                    <h2 class="title">Career Fair</h2>
                                    <p class="time"><i class="fa fa-clock-o"></i>09:45am - 16:00pm</p>
                                    <p class="location"><i class="fa fa-map-marker"></i>Library</p>                            
                                </div><!--//details-->
                            </div><!--event-item-->
                            <div class="event-item">
                                <p class="date-label">
                                    <span class="month">May</span>
                                    <span class="date-number">17</span>
                                </p>
                                <div class="details">
                                    <h2 class="title">Science Seminar</h2>
                                    <p class="time"><i class="fa fa-clock-o"></i>14:00pm - 18:00pm</p>
                                    <p class="location"><i class="fa fa-map-marker"></i>Library</p>                            
                                </div><!--//details-->
                            </div><!--event-item-->
                            <a class="read-more" href="events.html">All events<i class="fa fa-chevron-right"></i></a>
                        </div><!--//section-content-->
                    </section><!--//events-->
                </div><!--//col-md-3-->
                <div class="col-md-6">
                    <section class="course-finder" style="padding:16px;">
                        <h1 class="section-heading text-highlight"><span class="line"></span></h1>
                        <article class="news-item page-row has-divider clearfix row">       
                                <figure class="thumb col-md-2 col-sm-3 col-xs-4">
                                <!-- {!! HTML::image('assets/images/news/news-thumb-1.jpg', 'a picture', array('class' => 'img-responsive')) !!} -->
                                 
                                </figure>
                                <div class="details col-md-10 col-sm-9 col-xs-8">
                                    <h3 class="title"><a href="news-single.html">History of School</a></h3>
                                    <p>Our school is established in 1985. Mr. XYZ was the founder of this school. His excellent contribution leads to the ultimate success of this what we are getting today. This school is contributing to the cultural refreshment and development of this area. This school has many historical engagements. There are many successful persons who are contributing in the national level were our students.

This school has tremendous reputation in social developments. Students come here not only to learn but to be enlightened and skilled.

                                    </p>
                                    <a class="btn btn-theme col-sm-3  read-more" href="news-single.html">Read More<i class="fa fa-chevron-right"></i></a>
                                </div>
                            </article>
                    </section><!--//course-finder-->

                     <section class="course-finder" style="padding:16px;">
                        <article class="news-item page-row has-divider clearfix row">       
                                <figure class="thumb col-md-2 col-sm-3 col-xs-4">
                                   {!! HTML::image('assets/images/news/news-thumb-1.jpg', 'a picture', array('class' => 'img-responsive')) !!}
                                </figure>
                                <div class="details col-md-10 col-sm-9 col-xs-8">
                                    <h3 class="title"><a href="news-single.html">Chairman of Executive Council</a></h3>
                                    <p>There is no alternative of education. I am really proud to be a part of this school. This school is not only famous for its results but also its history and discipline. Hopefully, one day, this school will be the best school in Bangladesh. We are dedicatedly working on it.

I wish every success of this school!

Thanks

Chairman
Executive Council
School Name 
</p>
                                    <a class="btn btn-theme col-sm-3  read-more" href="news-single.html">Read More<i class="fa fa-chevron-right"></i></a>
                                </div>
                            </article>
                    </section><!--//course-finder-->


                


                </div>
                <div class="col-md-3">



                                    <section class="testimonials">
                        <h1 class="section-heading text-highlight"><span class="line">Principal’s Speech</span></h1>
                    <!--     <div class="carousel-controls">
                            <a class="prev" href="#testimonials-carousel" data-slide="prev"><i class="fa fa-caret-left"></i></a>
                            <a class="next" href="#testimonials-carousel" data-slide="next"><i class="fa fa-caret-right"></i></a>
                        </div><!--//carousel-controls--> 
                        <div class="section-content">
                            <div id="testimonials-carousel" class="testimonials-carousel carousel slide">
                                <div class="carousel-inner">
                                    <div class="item active">
                                        <blockquote class="quote">                                  
                                            <p><i class="fa fa-quote-left"></i>Education is one of the fundamental rights of a human being. We feel proud to the part of this education sector. Our school has been doing remarkable since 2001. All the teachers are trying to teach the students from their real experience and learning. I am  ....
</p>
                                            <a class="read-more" href="news-single.html">Read More<i class="fa fa-chevron-right"></i></a>                
                                        </blockquote>                
                                        <div class="row">
                                            <p class="people col-md-8 col-sm-3 col-xs-8"><span class="name">Principal</span><br /><span class="title">School Name </span></p>
                                            <!-- {!! HTML::image('assets/images/testimonials/profile-1.png', 'a picture', array('class' => 'profile col-md-4 pull-right')) !!} -->

                                        </div>                               
                                    </div><!--//item-->
                                   
                                    
                                </div><!--//carousel-inner-->
                            </div><!--//testimonials-carousel-->
                        </div><!--//section-content-->
                    </section><!--//testimonials-->
                    <section class="links">
                        <h1 class="section-heading text-highlight"><span class="line">Important Links</span></h1>
                        <div class="section-content">
                            <p><a href="#"><i class="fa fa-caret-right"></i>E-learning Portal</a></p>
                            <p><a href="#"><i class="fa fa-caret-right"></i>Gallery</a></p>
                            <p><a href="#"><i class="fa fa-caret-right"></i>Job Vacancies</a></p>
                            <p><a href="#"><i class="fa fa-caret-right"></i>Contact</a></p>
                        </div><!--//section-content-->
                    </section><!--//links-->



                </div><!--//col-md-3-->
            </div><!--//cols-wrapper-->
            <section class="promo box box-dark">        
                <div class="col-md-9">
                <h1 class="section-heading">Why Our School</h1>
                    <p>This school is well reputed both in terms of results and well organized system. It follows proper academic curriculum and maintain academic calendar. Both teachers and students find this school a real place to spread the light of knowledge.
This school has consistently been top performer in Comilla Education Board and committed to sustain it. This school will facilitate you from every sphere as possible. We feel proud to invite you at our school.
</p>   
                </div>  
                <div class="col-md-3">
                    <a class="btn btn-cta" href="#"><i class="fa fa-play-circle"></i>Apply Online</a>  
                </div>
            </section><!--//promo-->
        </div>

@stop